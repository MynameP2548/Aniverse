import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Providers from "./providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://aniverse-wheat.vercel.app"),

  title: {
    default: "Aniverse",
    template: "%s | Aniverse",
  },

  description:
    "Aniverse เว็บไซต์ดูอนิเมะออนไลน์ รวมอนิเมะพากย์ไทย ซับไทย อัปเดตตอนใหม่",

  keywords: [
    "Aniverse",
    "Anime",
    "ดูอนิเมะ",
    "อนิเมะ",
    "Anime Online",
    "พากย์ไทย",
    "ซับไทย",
  ],

  applicationName: "Aniverse",

  verification: {
    google: "98Egu2DAhSne2gwKwlU9egURt0dKsIpSN",
  },

  openGraph: {
    title: "Aniverse",
    description:
      "Aniverse เว็บไซต์ดูอนิเมะออนไลน์ รวมอนิเมะพากย์ไทย ซับไทย อัปเดตตอนใหม่",
    url: "https://aniverse-wheat.vercel.app",
    siteName: "Aniverse",
    locale: "th_TH",
    type: "website",
  },

  twitter: {
    card: "summary_large_image",
    title: "Aniverse",
    description:
      "Aniverse เว็บไซต์ดูอนิเมะออนไลน์ รวมอนิเมะพากย์ไทย ซับไทย อัปเดตตอนใหม่",
  },
};

const websiteJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "Aniverse",
  alternateName: "Aniverse Anime",
  url: "https://aniverse-wheat.vercel.app",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="th">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(websiteJsonLd),
          }}
        />

        <Providers>{children}</Providers>
      </body>
    </html>
  );
}